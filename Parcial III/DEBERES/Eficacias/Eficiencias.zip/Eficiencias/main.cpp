#include <iostream>
#include "Aplicaciones.cpp"
using namespace std;
int main() {
   double x,y;
   int z;
   x=5;
   y=8;
   z=5;
   double j[5]={2,4,2,6,8};
   float Matriz1[2][2] = {{1,2},{3,4}}; 
   string palabra="Estructuras";
   Aplicaciones app;
   	//Complejidad Constante
	cout<<"Mayor entre x and y \n"<<app.Mayor(x,y);
	//Complejidad Lineal
	cout<<"\nVector mostrar \n";
	app.escribeVector(j,z);
	//Complejidad Logaritmica
	cout<<"\nSuma mostrar \n";
	cout<<app.suma(j,z);
	//Complejidad Logaritmica Lineal
	cout<<"\nLogaritmo Lineal \n";
	app.ejemploC(z);
	//Complejidad Exponencial
	cout<<"\nRaiz Heron \n";
	app.raizHeron();
	//Complejidad Cuadratica
	cout<<"\nTranspuesta \n";
	app.traspuesta(Matriz1,2);
	//Complejidad Cubica
	cout<<"\nPalabras \n";
	cout<<app.wordEntropy(palabra);
    return 0;
}