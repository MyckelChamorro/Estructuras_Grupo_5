#include <iostream>
#include<stdlib.h>
#include<math.h>
#pragma once
using namespace std;
class Aplicaciones{
	public:
		//Complejidad Constante
		double Mayor(double x, double y);
		//Complejidad Lineal
		void escribeVector(double x[], int n);
		//Complejidad Logaritmica
		double suma(double d[], int n);
		//Complejidad Logaritmica Lineal
		void ejemploC(int x);	
		//Complejidad Exponencial
		void raizHeron();
		//Complejidad Cuadratica
		void traspuesta(float f[][2], int n);
		//Complejidad Cubica
		int wordEntropy(string palabra);
};
