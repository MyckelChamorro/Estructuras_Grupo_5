#include "Aplicaciones.h"
using namespace std;
//Complejidad Constante
double Aplicaciones::Mayor(double x, double y){
	 if (x > y)
 	return x;
	 else
 	return y;
}
	//Complejidad Lineal
void Aplicaciones::escribeVector(double x[], int n){
 	int j;
 	for (j = 0; j < n; j++)
 	{
 	cout << x[j];
 	}

}
	//Complejidad Logaritmica
	double Aplicaciones::suma(double d[], int n){
		int k ,s;
		 k = s = 0;
		  while (k < n)
		 {
		 s += d[k];
		 if (k == 0)
		 k = 2;
		 else
		 k *= 2;
		 }
		 return s;
	}
	//Complejidad Cuadratica
	void Aplicaciones::traspuesta(float f[][2], int n){
		 int i, j;
		 for (i = n - 2; i > 0; i--)
		 {
		 for (j = i + 1; j < n; j++)
		 {
		 float t;
		 t = f[i][j];
		 f[i][j] = f[j][i];
		 f[j][i] = t;
		 }
		 }
		cout<<"La matriz 1 es: "<<"\n"<<endl;
		for (size_t i{0};i<2;i++){
		for (size_t j{0};j<2;j++){
			cout<<" "<<f[i][j];
		}
		cout<<endl;
	}
	}
	//Complejidad Exponencial
		void Aplicaciones::raizHeron(){
		double numero=36.0;
		double a=4.0;
		double b = numero/a;
		a=(a+b)/2.0;
		while(fabs(numero - (a*a)) > 0.00000000001){
			printf("Valor: %.13f\n",a);
			b=numero/a;
			a=(a+b)/2.0;
		}	
		printf("Valor: %.13f\n",a);
		}
		//Complejidad Logaritmica Lineal
		void Aplicaciones::ejemploC(int x){
			int n,y;
			x = n ;
   			while ( x > 0 ) { 
      		y = x ;
     		 while ( y > 0 ) { 
         	 y = y - 1; 
     		 } 
     		 x = x / 2; 
  			 } 
  			 cout<<n;
		}
		//Complejidad Cubica
		int Aplicaciones::wordEntropy(string palabra){
			
		int length = palabra.length();
		int uniquewords = length;
		string compare = palabra;
		char save[17];
		int cond=0;
		
		for (int ii=0; ii < length; ii++)
		{
		
		    for (int jj=ii+1; jj < length; jj++)
		    {
		        for (int kk=0; kk<= ii; kk++)
		        {
		            if (save[kk] == palabra[ii]) {cond++;}
		        }
		        if (palabra[ii] == palabra[jj])
		        {
		            if (cond>0) {break;}
		            uniquewords--;
		        }
		    }
		
		    save[ii] = palabra[ii];
		    cond = 0;
		
		}
		return uniquewords;
		}